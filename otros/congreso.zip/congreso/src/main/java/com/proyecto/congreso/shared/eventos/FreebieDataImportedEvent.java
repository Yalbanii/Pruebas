package com.proyecto.congreso.shared.eventos;

import com.proyecto.congreso.points.dto.FreebiePointsData;

public record FreebieDataImportedEvent (FreebiePointsData data){
}
