package com.proyecto.congreso.shared.eventos;

import com.proyecto.congreso.asistencia.dto.ConferencePointsData;

public record ConferenceDataImportedEvent(ConferencePointsData data) {
}
